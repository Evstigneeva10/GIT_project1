import pygame
import os
from random import choice, randrange

BALLS = 20
FPS = 130
R = randrange(50, 255)
G = randrange(50, 255)
B = randrange(50, 255)
COLOR = (R, G, B)


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    image = pygame.image.load(fullname).convert()
    if colorkey is not None:
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


class Star(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__(all_sprites)
        self.image = pygame.transform.scale(load_image('star.png', -1), (14, 14))
        self.rect = self.image.get_rect()
        self.rect.x = width // 2 - self.image.get_width() // 2
        self.rect.y = 0
        self.pos = [self.rect.x, self.rect.y]
        self.mask = pygame.mask.from_surface(self.image)
        self.speed = [0, 0]
        self.in_sea = False
        self.polygon_coords = []
        self.lastx = self.rect.x
        self.lasty = self.rect.y
        self.borders = []

    def get_center_coords(self):
        return self.rect.x + self.image.get_width() // 2, self.rect.y + self.image.get_height() // 2

    def append_coord(self, coord):
        checker = CheckPoint(self.get_center_coords())
        if pygame.sprite.collide_mask(checker, sea):
            self.polygon_coords.append(coord)

    def set_last_coords(self, coord):
        x, y = coord
        border = Border(self.lastx, self.lasty, x, y)
        self.borders.append(border)
        self.lastx = x
        self.lasty = y

    def border_check(self):
        x, y = self.get_center_coords()
        border = Border(self.lastx, self.lasty, x, y)
        if pygame.sprite.spritecollideany(border, white_ball_sprites):
            return False
        border.kill()
        for el in self.borders:
            if pygame.sprite.spritecollideany(el, white_ball_sprites):
                return False
        return True

    def update(self):
        if not self.border_check():
            self.rect.x = width // 2 - self.image.get_width() // 2
            self.rect.y = 0
            self.pos = [self.rect.x, self.rect.y]
            self.speed = [0, 0]
            self.in_sea = False
            self.polygon_coords = []
            self.lastx = self.rect.x
            self.lasty = self.rect.y
            self.borders = []
            return
        if pygame.sprite.collide_mask(self, sea):
            self.in_sea = True
            self.append_coord(self.get_center_coords())
        if self.in_sea and not pygame.sprite.collide_mask(self, sea):
            self.speed = [0, 0]
            self.in_sea = False
        for coord in (0, 1):
            if (self.pos[coord] >= size[coord] - 14 and self.speed[coord] > 0 or
                    self.pos[coord] <= 0 and self.speed[coord] < 0):
                self.speed[coord] = 0
            self.pos[coord] += self.speed[coord]
        self.rect.x = self.pos[0]
        self.rect.y = self.pos[1]
        checker = CheckPoint(self.get_center_coords())
        if pygame.sprite.collide_mask(checker, land):
            if len(self.polygon_coords) > 1:
                start_coord = self.polygon_coords[0]
                finish_coord = self.polygon_coords[-1]
                land.modify(start_coord, finish_coord, self.polygon_coords)
            self.polygon_coords.clear()
            self.borders.clear()

    def draw_polygon(self):
        if len(self.polygon_coords) > 1:
            pygame.draw.aalines(screen, (255, 0, 0), False, tuple(self.polygon_coords), 5)


class CheckPoint(pygame.sprite.Sprite):
    def __init__(self, *coords):
        super().__init__(all_sprites)
        surf = pygame.Surface((1, 1), pygame.SRCALPHA)
        surf.fill((0, 0, 0, 255))
        self.image = surf
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect()
        self.rect.topleft = coords


class Border(pygame.sprite.Sprite):
    def __init__(self, x1, y1, x2, y2):
        super().__init__(all_sprites)
        if x1 == x2:
            surf = pygame.Surface((1, abs(y1 - y2)), pygame.SRCALPHA)
        else:
            surf = pygame.Surface((abs(x1 - x2), 1), pygame.SRCALPHA)
        surf.fill((0, 0, 0, 255))
        self.image = surf
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect()
        self.rect.x = min(x1, x2)
        self.rect.y = min(y1, y2)


class Land(pygame.sprite.Sprite):
    def __init__(self, *coords):
        super().__init__(all_sprites)
        surf = pygame.Surface((width, height), pygame.SRCALPHA)
        pygame.draw.polygon(surf, COLOR, tuple(coords))
        sea.set_image(coords)
        self.image = surf
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect()
        self.rect.topleft = (min(coords))

    def modify(self, start, stop, *coords):
        pass


class Sea(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__(all_sprites)
        surf0 = pygame.Surface((width, height), pygame.SRCALPHA)
        surf0.fill((0, 0, 0, 255))
        self.surface = surf0
        self.image = surf0
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)

    def set_image(self, coords):
        pygame.draw.polygon(self.image, (0, 0, 0, 0), tuple(coords))
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)


pygame.init()
size = width, height = 700, 700
screen = pygame.display.set_mode(size)
screen.fill(pygame.Color('black'))
all_sprites = pygame.sprite.Group()
ball_sprites = pygame.sprite.Group()
white_ball_sprites = pygame.sprite.Group()
black_ball_sprites = pygame.sprite.Group()
land_sprites = pygame.sprite.Group()
sea_sprites = pygame.sprite.Group()
player_sprites = pygame.sprite.Group()
sea = Sea()
sea_sprites.add(sea)
land = Land((0, 0), (20, 20), (width - 20, 20), (width - 20, height - 20), (20, height - 20), (20, 20), (0, 0),
            (0, height), (width, height), (width, 0))
land_sprites.add(land)
player = Star()
player_sprites.add(player)
running = True
clock = pygame.time.Clock()
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP]:
            player.speed = [0, -2]
            player.append_coord(player.get_center_coords())
        if keys[pygame.K_DOWN]:
            player.speed = [0, 2]
            player.append_coord(player.get_center_coords())
        if keys[pygame.K_LEFT]:
            player.speed = [-2, 0]
            player.append_coord(player.get_center_coords())
        if keys[pygame.K_RIGHT]:
            player.speed = [2, 0]
            player.append_coord(player.get_center_coords())
        if keys[pygame.K_SPACE]:
            player.speed = [0, 0]
    all_sprites.update()
    screen.fill(pygame.Color('black'))
    land_sprites.draw(screen)
    player.draw_polygon()
    player_sprites.draw(screen)
    pygame.display.flip()
    clock.tick(FPS)
pygame.quit()
