import pygame


print((0, 0) < (350, 20) < (700, 700))
print((680, 20) < (680, 339) < (680, 680))
pygame.init()
size = width, height = 500, 500
screen = pygame.display.set_mode(size)
screen.fill(pygame.Color('black'))
pygame.draw.aalines(screen, (0, 100, 0), False, ((3, 3), (100, 100), (100, 200)), 2)
pygame.draw.polygon(screen, (100, 50, 100), ((0, 0), (20, 20), (480, 20), (480, 480), (20, 480), (20, 20), (0, 0),
                                             (0, 500), (500, 500), (500, 0)))
pygame.draw.polygon(screen, (0, 100, 0), ((200, 200), (200, 300), (300, 300), (300, 200)))
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    pygame.display.flip()
