import pygame
import os
from random import choice, randrange


BALLS = 20
FPS = 130
R = randrange(50, 255)
G = randrange(50, 255)
B = randrange(50, 255)
COLOR = (R, G, B)


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    image = pygame.image.load(fullname).convert()
    if colorkey is not None:
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


class Land(pygame.sprite.Sprite):
    def __init__(self, *coords):
        super().__init__(all_sprites)
        surf = pygame.Surface((width, height), pygame.SRCALPHA)
        pygame.draw.polygon(surf, COLOR, tuple(coords))
        sea.set_image(coords)
        self.image = surf
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect()
        self.rect.topleft = (min(coords))


class Sea(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__(all_sprites)
        surf0 = pygame.Surface((width, height), pygame.SRCALPHA)
        surf0.fill((0, 0, 0, 255))
        self.surface = surf0
        self.image = surf0
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)

    def set_image(self, coords):
        pygame.draw.polygon(self.image, (0, 0, 0, 0), tuple(coords))
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)


class WhiteBall(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__(all_sprites)
        arr = [-1, -0.9, -0.8, -0.7, -0.6, -0.5, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        self.speed = [choice(arr), choice(arr)]
        self.pos = [randrange(40, width - 40), randrange(40, height - 40)]
        self.delta = [0.0, 0.0]
        self.topleft = (self.pos[0], self.pos[1])
        self.image = pygame.transform.scale(load_image('white-tennis-ball.png', -1), (10, 10))
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect()
        self.flag = [True, True]

    def update(self):
        if pygame.sprite.collide_mask(self, land) and all(self.flag):
            if self.speed[1] < 0:
                check1 = CheckBall(self.rect.x - 1, self.rect.y - 1)
                check2 = CheckBall(self.rect.x + 1, self.rect.y - 1)
                if pygame.sprite.collide_mask(check1, land) and pygame.sprite.collide_mask(check2, land):
                    self.flag[1] = False
                    self.speed[1] = -self.speed[1]
                    self.delta[1] = self.speed[1]
            else:
                check1 = CheckBall(self.rect.x - 1, self.rect.y + 1)
                check2 = CheckBall(self.rect.x + 1, self.rect.y + 1)
                if pygame.sprite.collide_mask(check1, land) and pygame.sprite.collide_mask(check2, land):
                    self.flag[1] = False
                    self.speed[1] = -self.speed[1]
                    self.delta[1] = self.speed[1]
            if self.speed[0] < 0:
                check1 = CheckBall(self.rect.x - 1, self.rect.y - 1)
                check2 = CheckBall(self.rect.x - 1, self.rect.y + 1)
                if pygame.sprite.collide_mask(check1, land) and pygame.sprite.collide_mask(check2, land):
                    self.flag[0] = False
                    self.speed[0] = -self.speed[0]
                    self.delta[0] = self.speed[0]
            else:
                check1 = CheckBall(self.rect.x + 1, self.rect.y - 1)
                check2 = CheckBall(self.rect.x + 1, self.rect.y + 1)
                if pygame.sprite.collide_mask(check1, land) and pygame.sprite.collide_mask(check2, land):
                    self.flag[0] = False
                    self.speed[0] = -self.speed[0]
                    self.delta[0] = self.speed[0]
        for coord in (0, 1):
            self.delta[coord] += self.speed[coord]
            if self.delta[coord] >= 1:
                self.flag[coord] = True
                self.pos[coord] += 1
                self.delta[coord] -= 1
            if self.delta[coord] <= -1:
                self.flag[coord] = True
                self.pos[coord] -= 1
                self.delta[coord] += 1
        self.rect.x = self.pos[0]
        self.rect.y = self.pos[1]


class BlackBall(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__(all_sprites)
        arr = [-1, -0.9, -0.8, -0.7, -0.6, -0.5, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        self.speed = [choice(arr), choice(arr)]
        arr1 = [0, 1, 2, 3, 4, 5, width - 15, width - 14, width - 13, width - 12, width - 11]
        arr2 = [0, 1, 2, 3, 4, 5, height - 15, height - 14, height - 13, height - 12, height - 11]
        flag = choice([0, 1])
        if flag:
            self.pos = [choice(arr1), randrange(0, height)]
        else:
            self.pos = [randrange(0, width), choice(arr2)]
        self.delta = [0.0, 0.0]
        self.topleft = (self.pos[0], self.pos[1])
        self.image = pygame.transform.scale(load_image('black-tennis-ball.png', -1), (10, 10))
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect()
        self.flag = [True, True]

    def update(self):
        if pygame.sprite.collide_mask(self, sea) and all(self.flag):
            if self.speed[1] < 0:
                check1 = CheckBall(self.rect.x - 1, self.rect.y - 1)
                check2 = CheckBall(self.rect.x + 1, self.rect.y - 1)
                if pygame.sprite.collide_mask(check1, sea) and pygame.sprite.collide_mask(check2, sea):
                    self.flag[1] = False
                    self.speed[1] = -self.speed[1]
                    self.delta[1] = self.speed[1]
            else:
                check1 = CheckBall(self.rect.x - 1, self.rect.y + 1)
                check2 = CheckBall(self.rect.x + 1, self.rect.y + 1)
                if pygame.sprite.collide_mask(check1, sea) and pygame.sprite.collide_mask(check2, sea):
                    self.flag[1] = False
                    self.speed[1] = -self.speed[1]
                    self.delta[1] = self.speed[1]
            if self.speed[0] < 0:
                check1 = CheckBall(self.rect.x - 1, self.rect.y - 1)
                check2 = CheckBall(self.rect.x - 1, self.rect.y + 1)
                if pygame.sprite.collide_mask(check1, sea) and pygame.sprite.collide_mask(check2, sea):
                    self.flag[0] = False
                    self.speed[0] = -self.speed[0]
                    self.delta[0] = self.speed[0]
            else:
                check1 = CheckBall(self.rect.x + 1, self.rect.y - 1)
                check2 = CheckBall(self.rect.x + 1, self.rect.y + 1)
                if pygame.sprite.collide_mask(check1, sea) and pygame.sprite.collide_mask(check2, sea):
                    self.flag[0] = False
                    self.speed[0] = -self.speed[0]
                    self.delta[0] = self.speed[0]
        for coord in (0, 1):
            if self.pos[coord] >= size[coord] - 10 or self.pos[coord] <= 0:
                self.flag[coord] = False
                self.speed[coord] = -self.speed[coord]
                self.delta[coord] = self.speed[coord]
            self.delta[coord] += self.speed[coord]
            if self.delta[coord] >= 1:
                self.flag[coord] = True
                self.pos[coord] += 1
                self.delta[coord] -= 1
            if self.delta[coord] <= -1:
                self.flag[coord] = True
                self.pos[coord] -= 1
                self.delta[coord] += 1
        self.rect.x = self.pos[0]
        self.rect.y = self.pos[1]


class CheckBall(pygame.sprite.Sprite):
    def __init__(self, *coords):
        super().__init__(all_sprites)
        self.topleft = coords
        self.image = pygame.Surface((10, 10), pygame.SRCALPHA)
        self.image.fill((0, 0, 0, 255))
        self.rect = self.image.get_rect()
        self.rect.x = coords[0]
        self.rect.y = coords[1]
        self.mask = pygame.mask.from_surface(self.image)


pygame.init()
size = width, height = 700, 700
screen = pygame.display.set_mode(size)
screen.fill(pygame.Color('black'))
all_sprites = pygame.sprite.Group()
ball_sprites = pygame.sprite.Group()
white_ball_sprites = pygame.sprite.Group()
black_ball_sprites = pygame.sprite.Group()
land_sprites = pygame.sprite.Group()
sea_sprites = pygame.sprite.Group()
sea = Sea()
sea_sprites.add(sea)
for i in range(BALLS):
    ball = WhiteBall()
    ball_sprites.add(ball)
    white_ball_sprites.add(ball)
for i in range(2):
    ball = BlackBall()
    ball_sprites.add(ball)
    black_ball_sprites.add(ball)
land = Land((0, 0), (20, 20), (width - 20, 20), (width - 20, height - 20), (20, height - 20), (20, 20), (0, 0),
            (0, height), (width, height), (width, 0))
land_sprites.add(land)
running = True
clock = pygame.time.Clock()
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    all_sprites.update()
    screen.fill(pygame.Color('black'))
    land_sprites.draw(screen)
    ball_sprites.draw(screen)
    pygame.display.flip()
    clock.tick(FPS)
pygame.quit()
